import os, sys, json, threading
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from datetime import datetime

BASE_DIR=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from db.connection import run_query
from detection.analyzer import process_flow
from detection.sniffer import run_simulation
from werkzeug.security import check_password_hash

FRONTEND_DIR=os.path.abspath(os.path.join(BASE_DIR,'..','frontend'))
SESSIONS={}

def safe(v):
    if isinstance(v,(datetime,)): return v.isoformat(sep=' ')
    return v

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw): super().__init__(*a,directory=FRONTEND_DIR,**kw)
    def log_message(self, fmt,*args): print(fmt%args)
    def _json(self,obj,status=200,headers=None):
        def conv(x):
            if isinstance(x,datetime): return x.isoformat(sep=' ')
            raise TypeError
        data=json.dumps(obj,default=conv).encode()
        self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.send_header('Access-Control-Allow-Origin','*')
        if headers:
            for k,v in headers.items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(data)
    def _body(self):
        n=int(self.headers.get('Content-Length',0)); raw=self.rfile.read(n) if n else b'{}'
        try:return json.loads(raw.decode() or '{}')
        except:return {}
    def _sid(self):
        c=self.headers.get('Cookie','')
        for part in c.split(';'):
            if part.strip().startswith('nids_session='): return part.strip().split('=',1)[1]
    def _user(self):
        return SESSIONS.get(self._sid())
    def _require(self):
        u=self._user()
        if not u:self._json({'error':'unauthorized'},401); return None
        return u
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS'); self.send_header('Access-Control-Allow-Headers','Content-Type'); self.end_headers()
    def do_POST(self):
        p=urlparse(self.path).path; data=self._body()
        if p=='/api/login':
            username=data.get('username'); password=data.get('password')
            if not username or not password:return self._json({'error':'username and password required'},400)
            admin=run_query('SELECT * FROM admins WHERE username=%s',(username,),fetch_one=True)
            if not admin or not check_password_hash(admin['password_hash'],password):return self._json({'error':'invalid credentials'},401)
            import secrets; sid=secrets.token_urlsafe(24); SESSIONS[sid]={'admin_id':admin['admin_id'],'username':admin['username'],'role':admin['role']}
            run_query('UPDATE admins SET last_login=CURRENT_TIMESTAMP WHERE admin_id=%s',(admin['admin_id'],),commit=True)
            return self._json({'message':'login successful','username':admin['username'],'role':admin['role']},headers={'Set-Cookie':f'nids_session={sid}; Path=/; SameSite=Lax'})
        if p=='/api/logout':
            sid=self._sid(); SESSIONS.pop(sid,None); return self._json({'message':'logged out'},headers={'Set-Cookie':'nids_session=; Path=/; Max-Age=0'})
        u=self._require()
        if not u:return
        if p.startswith('/api/alerts/') and p.endswith('/acknowledge'):
            aid=int(p.split('/')[3]); run_query("UPDATE alerts SET status='acknowledged', acknowledged_by=%s WHERE alert_id=%s",(u['admin_id'],aid),commit=True); return self._json({'message':'alert acknowledged'})
        if p.startswith('/api/alerts/') and p.endswith('/resolve'):
            aid=int(p.split('/')[3]); alert=run_query('SELECT * FROM alerts WHERE alert_id=%s',(aid,),fetch_one=True)
            if not alert:return self._json({'error':'not found'},404)
            run_query("UPDATE alerts SET status='resolved', resolved_at=CURRENT_TIMESTAMP WHERE alert_id=%s",(aid,),commit=True)
            d=run_query('SELECT * FROM detections WHERE detection_id=%s',(alert['detection_id'],),fetch_one=True); t=run_query('SELECT * FROM network_traffic WHERE traffic_id=%s',(d['traffic_id'],),fetch_one=True)
            run_query('INSERT INTO detection_history (detection_id,src_ip,dst_ip,attack_type,severity,action_taken) VALUES (%s,%s,%s,%s,%s,%s)',(d['detection_id'],t['src_ip'],t['dst_ip'],d['attack_type'],d['severity'],'Resolved by analyst'),commit=True)
            return self._json({'message':'alert resolved and archived to history'})
        if p=='/api/reports/generate':
            a=data.get('date_from'); b=data.get('date_to'); typ=data.get('report_type','custom')
            total=run_query('SELECT COUNT(*) AS c FROM network_traffic WHERE captured_at BETWEEN %s AND %s',(a,b),fetch_one=True)['c']; alerts=run_query('SELECT COUNT(*) AS c FROM alerts WHERE created_at BETWEEN %s AND %s',(a,b),fetch_one=True)['c']
            breakdown=run_query('SELECT attack_type,COUNT(*) AS count,severity FROM detections WHERE detected_at BETWEEN %s AND %s GROUP BY attack_type,severity ORDER BY count DESC',(a,b),fetch=True)
            rid=run_query('INSERT INTO reports (admin_id,report_type,date_from,date_to,total_traffic,total_alerts) VALUES (%s,%s,%s,%s,%s,%s)',(u['admin_id'],typ,a,b,total,alerts),commit=True)
            return self._json({'report_id':rid,'date_from':a,'date_to':b,'total_traffic':total,'total_alerts':alerts,'breakdown':breakdown})
        return self._json({'error':'not found'},404)
    def do_GET(self):
        p=urlparse(self.path).path; q=parse_qs(urlparse(self.path).query)
        if p=='/api/session':
            u=self._user(); return self._json({'authenticated':True,'username':u['username'],'role':u['role']} if u else {'authenticated':False},200 if u else 401)
        if p.startswith('/api/'):
            if not self._require():return
            if p=='/api/dashboard/summary':
                total=run_query('SELECT COUNT(*) AS c FROM network_traffic',fetch_one=True)['c']; sus=run_query("SELECT COUNT(*) AS c FROM network_traffic WHERE status='suspicious'",fetch_one=True)['c']; active=run_query("SELECT COUNT(*) AS c FROM alerts WHERE status='new'",fetch_one=True)['c']
                top=run_query('SELECT attack_type,COUNT(*) AS count FROM detections GROUP BY attack_type ORDER BY count DESC LIMIT 5',fetch=True); recent=run_query('SELECT alert_id,title,severity,status,created_at FROM alerts ORDER BY created_at DESC LIMIT 10',fetch=True); over=run_query("SELECT DATE_FORMAT(captured_at,'%Y-%m-%d %H:%i') AS minute,COUNT(*) AS total,SUM(status='suspicious') AS suspicious FROM network_traffic WHERE captured_at>=NOW()-INTERVAL 1 HOUR GROUP BY minute ORDER BY minute",fetch=True)
                return self._json({'total_traffic':total,'suspicious_traffic':sus,'active_alerts':active,'top_attack_types':top,'recent_alerts':recent,'traffic_over_time':over})
            if p in ('/api/traffic','/api/traffic/live'):
                limit=20 if p.endswith('/live') else int(q.get('limit',['100'])[0]); status=q.get('status',[None])[0]
                if status: rows=run_query('SELECT * FROM network_traffic WHERE status=%s ORDER BY captured_at DESC LIMIT %s',(status,limit),fetch=True)
                else: rows=run_query('SELECT * FROM network_traffic ORDER BY captured_at DESC LIMIT %s',(limit,),fetch=True)
                return self._json(rows)
            if p=='/api/ips': return self._json(run_query('SELECT * FROM ip_details ORDER BY suspicious_count DESC,last_seen DESC LIMIT 100',fetch=True))
            if p.startswith('/api/ip/'):
                ip=p.split('/api/ip/',1)[1]; d=run_query('SELECT * FROM ip_details WHERE ip_address=%s',(ip,),fetch_one=True)
                if not d:return self._json({'error':'IP not found'},404)
                h=run_query('SELECT nt.*,d.attack_type,d.severity FROM network_traffic nt LEFT JOIN detections d ON d.traffic_id=nt.traffic_id WHERE nt.src_ip=%s ORDER BY nt.captured_at DESC LIMIT 50',(ip,),fetch=True); return self._json({'details':d,'history':h})
            if p=='/api/alerts': return self._json(run_query('SELECT a.*,d.attack_type,d.confidence_score,d.rule_matched FROM alerts a LEFT JOIN detections d ON a.detection_id=d.detection_id ORDER BY a.created_at DESC LIMIT 200',fetch=True))
            if p=='/api/history': return self._json(run_query('SELECT * FROM detection_history ORDER BY archived_at DESC LIMIT 200',fetch=True))
            if p=='/api/reports': return self._json(run_query('SELECT * FROM reports ORDER BY generated_at DESC LIMIT 50',fetch=True))
            return self._json({'error':'not found'},404)
        return super().do_GET()

def main():
    threading.Thread(target=run_simulation,kwargs={'interval':0.5},daemon=True).start()
    server=ThreadingHTTPServer(('127.0.0.1',5000),Handler)
    print('NIDS running at http://127.0.0.1:5000'); server.serve_forever()
if __name__=='__main__': main()
