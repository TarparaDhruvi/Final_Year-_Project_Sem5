import os

class Config:
    # --- MySQL connection settings ---
    DB_HOST = os.environ.get("DB_HOST", "localhost")
    DB_USER = os.environ.get("DB_USER", "root")
    DB_PASSWORD = os.environ.get("DB_PASSWORD", "")
    DB_NAME = os.environ.get("DB_NAME", "nids_db")
    DB_PORT = int(os.environ.get("DB_PORT", 3306))

    # --- Flask settings ---
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-in-production")
    DEBUG = True

    # --- Detection thresholds (tune these for your demo) ---
    PORT_SCAN_THRESHOLD = 15        # distinct dst ports from one src IP within window
    PORT_SCAN_WINDOW_SECONDS = 10

    SYN_FLOOD_THRESHOLD = 50        # SYN packets from one src IP within window
    SYN_FLOOD_WINDOW_SECONDS = 5

    BRUTE_FORCE_THRESHOLD = 8       # failed connection attempts to same dst_port (e.g. 22, 3389)
    BRUTE_FORCE_WINDOW_SECONDS = 30

    DOS_PACKET_RATE_THRESHOLD = 200 # packets/sec from single src IP
    DOS_WINDOW_SECONDS = 5

    # Ports commonly targeted for brute force (SSH, RDP, FTP, Telnet)
    SENSITIVE_PORTS = [22, 23, 21, 3389, 3306]
