"""
Run this once after creating the schema to add a default admin login.
Usage:
    python seed_admin.py
"""
from werkzeug.security import generate_password_hash
from db.connection import run_query

USERNAME = "admin"
PASSWORD = "admin123"   # change this after first login
EMAIL = "admin@example.com"

if __name__ == "__main__":
    existing = run_query(
        "SELECT admin_id FROM admins WHERE username=%s", (USERNAME,), fetch_one=True
    )
    if existing:
        print(f"Admin '{USERNAME}' already exists (id={existing['admin_id']}).")
    else:
        password_hash = generate_password_hash(PASSWORD)
        admin_id = run_query(
            "INSERT INTO admins (username, password_hash, email) VALUES (%s,%s,%s)",
            (USERNAME, password_hash, EMAIL),
            commit=True,
        )
        print(f"Created admin '{USERNAME}' (id={admin_id}) with password '{PASSWORD}'.")
        print("Log in and change this password before any real deployment.")
