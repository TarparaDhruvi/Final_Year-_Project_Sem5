from flask import Blueprint, request, jsonify, session
from werkzeug.security import check_password_hash
from db.connection import run_query

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/api/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "username and password required"}), 400

    admin = run_query(
        "SELECT * FROM admins WHERE username = %s", (username,), fetch_one=True
    )

    if not admin or not check_password_hash(admin["password_hash"], password):
        return jsonify({"error": "invalid credentials"}), 401

    session["admin_id"] = admin["admin_id"]
    session["username"] = admin["username"]
    session["role"] = admin["role"]

    run_query(
        "UPDATE admins SET last_login = CURRENT_TIMESTAMP WHERE admin_id = %s",
        (admin["admin_id"],), commit=True
    )

    return jsonify({
        "message": "login successful",
        "username": admin["username"],
        "role": admin["role"]
    })


@auth_bp.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"message": "logged out"})


@auth_bp.route("/api/session", methods=["GET"])
def check_session():
    if "admin_id" not in session:
        return jsonify({"authenticated": False}), 401
    return jsonify({
        "authenticated": True,
        "username": session.get("username"),
        "role": session.get("role")
    })
