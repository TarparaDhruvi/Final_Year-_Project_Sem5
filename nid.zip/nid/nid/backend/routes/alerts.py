from flask import Blueprint, request, jsonify, session
from db.connection import run_query

alerts_bp = Blueprint("alerts", __name__)


@alerts_bp.route("/api/alerts", methods=["GET"])
def list_alerts():
    status = request.args.get("status")
    if status:
        rows = run_query(
            """SELECT a.*, d.attack_type, d.severity AS detection_severity
               FROM alerts a JOIN detections d ON d.detection_id = a.detection_id
               WHERE a.status = %s ORDER BY a.created_at DESC""",
            (status,), fetch=True
        )
    else:
        rows = run_query(
            """SELECT a.*, d.attack_type, d.severity AS detection_severity
               FROM alerts a JOIN detections d ON d.detection_id = a.detection_id
               ORDER BY a.created_at DESC LIMIT 200""",
            fetch=True
        )
    return jsonify(rows)


@alerts_bp.route("/api/alerts/<int:alert_id>/acknowledge", methods=["POST"])
def acknowledge_alert(alert_id):
    admin_id = session.get("admin_id")
    run_query(
        """UPDATE alerts SET status='acknowledged', acknowledged_by=%s
           WHERE alert_id=%s""",
        (admin_id, alert_id), commit=True
    )
    return jsonify({"message": "alert acknowledged"})


@alerts_bp.route("/api/alerts/<int:alert_id>/resolve", methods=["POST"])
def resolve_alert(alert_id):
    alert = run_query(
        "SELECT * FROM alerts WHERE alert_id=%s", (alert_id,), fetch_one=True
    )
    if not alert:
        return jsonify({"error": "not found"}), 404

    run_query(
        """UPDATE alerts SET status='resolved', resolved_at=CURRENT_TIMESTAMP
           WHERE alert_id=%s""",
        (alert_id,), commit=True
    )

    detection = run_query(
        "SELECT * FROM detections WHERE detection_id=%s",
        (alert["detection_id"],), fetch_one=True
    )
    traffic = run_query(
        "SELECT * FROM network_traffic WHERE traffic_id=%s",
        (detection["traffic_id"],), fetch_one=True
    )
    run_query(
        """INSERT INTO detection_history
           (detection_id, src_ip, dst_ip, attack_type, severity, action_taken)
           VALUES (%s,%s,%s,%s,%s,%s)""",
        (detection["detection_id"], traffic["src_ip"], traffic["dst_ip"],
         detection["attack_type"], detection["severity"], "Resolved by analyst"),
        commit=True
    )

    return jsonify({"message": "alert resolved and archived to history"})


@alerts_bp.route("/api/history", methods=["GET"])
def detection_history():
    rows = run_query(
        "SELECT * FROM detection_history ORDER BY archived_at DESC LIMIT 200",
        fetch=True
    )
    return jsonify(rows)
