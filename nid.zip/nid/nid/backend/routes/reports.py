from flask import Blueprint, request, jsonify, session
from db.connection import run_query

reports_bp = Blueprint("reports", __name__)


@reports_bp.route("/api/reports/generate", methods=["POST"])
def generate_report():
    data = request.get_json(silent=True) or {}
    date_from = data.get("date_from")
    date_to = data.get("date_to")
    report_type = data.get("report_type", "custom")

    total_traffic = run_query(
        """SELECT COUNT(*) AS c FROM network_traffic
           WHERE captured_at BETWEEN %s AND %s""",
        (date_from, date_to), fetch_one=True
    )["c"]

    total_alerts = run_query(
        """SELECT COUNT(*) AS c FROM alerts
           WHERE created_at BETWEEN %s AND %s""",
        (date_from, date_to), fetch_one=True
    )["c"]

    breakdown = run_query(
        """SELECT attack_type, COUNT(*) AS count, severity
           FROM detections
           WHERE detected_at BETWEEN %s AND %s
           GROUP BY attack_type, severity
           ORDER BY count DESC""",
        (date_from, date_to), fetch=True
    )

    report_id = run_query(
        """INSERT INTO reports
           (admin_id, report_type, date_from, date_to, total_traffic, total_alerts)
           VALUES (%s,%s,%s,%s,%s,%s)""",
        (session.get("admin_id"), report_type, date_from, date_to,
         total_traffic, total_alerts),
        commit=True
    )

    return jsonify({
        "report_id": report_id,
        "date_from": date_from,
        "date_to": date_to,
        "total_traffic": total_traffic,
        "total_alerts": total_alerts,
        "breakdown": breakdown,
    })


@reports_bp.route("/api/reports", methods=["GET"])
def list_reports():
    rows = run_query(
        "SELECT * FROM reports ORDER BY generated_at DESC LIMIT 50", fetch=True
    )
    return jsonify(rows)
