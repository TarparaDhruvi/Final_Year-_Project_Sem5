from flask import Blueprint, request, jsonify
from db.connection import run_query

traffic_bp = Blueprint("traffic", __name__)


@traffic_bp.route("/api/traffic", methods=["GET"])
def list_traffic():
    limit = int(request.args.get("limit", 100))
    status = request.args.get("status")  # 'normal' | 'suspicious' | None

    if status:
        rows = run_query(
            "SELECT * FROM network_traffic WHERE status=%s "
            "ORDER BY captured_at DESC LIMIT %s",
            (status, limit), fetch=True
        )
    else:
        rows = run_query(
            "SELECT * FROM network_traffic ORDER BY captured_at DESC LIMIT %s",
            (limit,), fetch=True
        )
    return jsonify(rows)


@traffic_bp.route("/api/traffic/live", methods=["GET"])
def live_traffic():
    """Poll this every few seconds from the dashboard for a 'live' feel."""
    rows = run_query(
        "SELECT * FROM network_traffic ORDER BY captured_at DESC LIMIT 20",
        fetch=True
    )
    return jsonify(rows)


@traffic_bp.route("/api/ip/<ip_address>", methods=["GET"])
def ip_details(ip_address):
    details = run_query(
        "SELECT * FROM ip_details WHERE ip_address = %s",
        (ip_address,), fetch_one=True
    )
    if not details:
        return jsonify({"error": "IP not found"}), 404

    history = run_query(
        """SELECT nt.*, d.attack_type, d.severity
           FROM network_traffic nt
           LEFT JOIN detections d ON d.traffic_id = nt.traffic_id
           WHERE nt.src_ip = %s
           ORDER BY nt.captured_at DESC LIMIT 50""",
        (ip_address,), fetch=True
    )

    return jsonify({"details": details, "history": history})


@traffic_bp.route("/api/ips", methods=["GET"])
def list_ips():
    rows = run_query(
        "SELECT * FROM ip_details ORDER BY suspicious_count DESC, last_seen DESC LIMIT 100",
        fetch=True
    )
    return jsonify(rows)
