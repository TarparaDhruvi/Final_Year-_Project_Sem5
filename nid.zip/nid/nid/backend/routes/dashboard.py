from flask import Blueprint, jsonify
from db.connection import run_query

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/api/dashboard/summary", methods=["GET"])
def summary():
    total_traffic = run_query(
        "SELECT COUNT(*) AS c FROM network_traffic", fetch_one=True
    )["c"]

    suspicious_traffic = run_query(
        "SELECT COUNT(*) AS c FROM network_traffic WHERE status='suspicious'",
        fetch_one=True
    )["c"]

    active_alerts = run_query(
        "SELECT COUNT(*) AS c FROM alerts WHERE status='new'", fetch_one=True
    )["c"]

    top_attack_types = run_query(
        """SELECT attack_type, COUNT(*) AS count FROM detections
           GROUP BY attack_type ORDER BY count DESC LIMIT 5""",
        fetch=True
    )

    recent_alerts = run_query(
        """SELECT a.alert_id, a.title, a.severity, a.status, a.created_at
           FROM alerts a ORDER BY a.created_at DESC LIMIT 10""",
        fetch=True
    )

    traffic_over_time = run_query(
        """SELECT DATE_FORMAT(captured_at, '%Y-%m-%d %H:%i') AS minute,
                  COUNT(*) AS total,
                  SUM(status='suspicious') AS suspicious
           FROM network_traffic
           WHERE captured_at >= NOW() - INTERVAL 1 HOUR
           GROUP BY minute ORDER BY minute""",
        fetch=True
    )

    return jsonify({
        "total_traffic": total_traffic,
        "suspicious_traffic": suspicious_traffic,
        "active_alerts": active_alerts,
        "top_attack_types": top_attack_types,
        "recent_alerts": recent_alerts,
        "traffic_over_time": traffic_over_time,
    })
