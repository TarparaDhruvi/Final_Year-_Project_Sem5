"""
Ties together: incoming flow -> rules_engine (+ optional ml_model)
-> store in network_traffic -> if suspicious, create detection + alert.
"""

from datetime import datetime, timedelta
from db.connection import run_query
from detection.rules_engine import run_all_rules
from detection.ml_model import predict as ml_predict


def get_recent_flows(seconds=30, limit=500):
    """Pull a recent window of traffic to give the rules engine context."""
    cutoff = datetime.utcnow() - timedelta(seconds=seconds)
    return run_query(
        "SELECT * FROM network_traffic WHERE captured_at >= %s "
        "ORDER BY captured_at DESC LIMIT %s",
        (cutoff, limit),
        fetch=True,
    )


def process_flow(flow: dict):
    """
    flow keys expected: src_ip, dst_ip, src_port, dst_port, protocol,
    packet_size, flag, duration, packets_count, bytes_count
    """
    recent_flows = get_recent_flows()

    verdict = run_all_rules(recent_flows, flow)
    if not verdict:
        verdict = ml_predict(flow)  # fall back to ML layer if rules found nothing

    status = "suspicious" if verdict else "normal"

    traffic_id = run_query(
        """INSERT INTO network_traffic
           (src_ip, dst_ip, src_port, dst_port, protocol, packet_size,
            flag, duration, packets_count, bytes_count, status)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (
            flow["src_ip"], flow["dst_ip"], flow.get("src_port"),
            flow.get("dst_port"), flow.get("protocol"), flow.get("packet_size", 0),
            flow.get("flag"), flow.get("duration", 0), flow.get("packets_count", 1),
            flow.get("bytes_count", 0), status,
        ),
        commit=True,
    )

    _update_ip_details(flow["src_ip"], suspicious=bool(verdict))

    if verdict:
        detection_id = run_query(
            """INSERT INTO detections
               (traffic_id, detection_method, attack_type, confidence_score,
                severity, rule_matched)
               VALUES (%s,%s,%s,%s,%s,%s)""",
            (
                traffic_id,
                "ml" if verdict["rule_matched"] == "ISOLATION_FOREST" else "rule",
                verdict["attack_type"], verdict["confidence_score"],
                verdict["severity"], verdict["rule_matched"],
            ),
            commit=True,
        )

        run_query(
            """INSERT INTO alerts (detection_id, title, description, severity)
               VALUES (%s,%s,%s,%s)""",
            (
                detection_id,
                f"{verdict['attack_type']} detected from {flow['src_ip']}",
                f"Source {flow['src_ip']} -> Destination {flow['dst_ip']}:"
                f"{flow.get('dst_port')} matched rule {verdict['rule_matched']}.",
                verdict["severity"],
            ),
            commit=True,
        )

    return {"status": status, "traffic_id": traffic_id, "verdict": verdict}


def _update_ip_details(ip_address, suspicious=False):
    run_query(
        """INSERT INTO ip_details (ip_address, total_requests, suspicious_count)
           VALUES (%s, 1, %s)
           ON DUPLICATE KEY UPDATE
             total_requests = total_requests + 1,
             suspicious_count = suspicious_count + %s,
             last_seen = CURRENT_TIMESTAMP""",
        (ip_address, 1 if suspicious else 0, 1 if suspicious else 0),
        commit=True,
    )
