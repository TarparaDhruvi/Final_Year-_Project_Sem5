"""
Optional ML-based anomaly detection layer.

This is intentionally simple (IsolationForest on a handful of numeric
features) so it trains fast and works with only simulated/dataset traffic.
It's meant to complement rules_engine.py, not replace it: rules catch known
attack signatures; this catches "weird but unlabeled" traffic.

To use:
    1. pip install scikit-learn pandas joblib
    2. Train once on a batch of historical `network_traffic` rows:
           python ml_model.py train
    3. In the live pipeline, call `predict(flow)` to get an anomaly flag.
"""

import os
import joblib
import numpy as np
from sklearn.ensemble import IsolationForest

MODEL_PATH = os.path.join(os.path.dirname(__file__), "anomaly_model.joblib")

FEATURE_KEYS = ["packet_size", "duration", "packets_count", "bytes_count"]


def extract_features(flow: dict) -> list:
    return [flow.get(k, 0) or 0 for k in FEATURE_KEYS]


def train(flows: list):
    """flows: list of dicts from network_traffic table (mostly 'normal' ones)."""
    X = np.array([extract_features(f) for f in flows])
    model = IsolationForest(
        n_estimators=100,
        contamination=0.05,  # assume ~5% of traffic is anomalous
        random_state=42,
    )
    model.fit(X)
    joblib.dump(model, MODEL_PATH)
    print(f"Model trained on {len(flows)} flows and saved to {MODEL_PATH}")


def predict(flow: dict):
    """Returns a dict like the rules_engine outputs, or None if normal."""
    if not os.path.exists(MODEL_PATH):
        return None  # model not trained yet — skip ML layer gracefully

    model = joblib.load(MODEL_PATH)
    X = np.array([extract_features(flow)])
    prediction = model.predict(X)[0]        # 1 = normal, -1 = anomaly
    score = model.decision_function(X)[0]   # lower = more anomalous

    if prediction == -1:
        confidence = float(min(1.0, max(0.5, 1 - (score + 0.5))))
        return {
            "attack_type": "Anomalous Traffic (ML)",
            "severity": "medium",
            "rule_matched": "ISOLATION_FOREST",
            "confidence_score": round(confidence, 2),
        }
    return None


if __name__ == "__main__":
    import sys
    from db.connection import run_query

    if len(sys.argv) > 1 and sys.argv[1] == "train":
        rows = run_query(
            "SELECT packet_size, duration, packets_count, bytes_count "
            "FROM network_traffic WHERE status='normal' LIMIT 5000",
            fetch=True,
        )
        if not rows:
            print("No normal traffic found to train on yet.")
        else:
            train(rows)
