"""
Rule-based intrusion detection.

Each function inspects a rolling window of recent `network_traffic` rows
(passed in as a list of dicts) plus the newly-arrived flow, and returns
either None (no attack) or a dict describing the detection:

    {
        "attack_type": "Port Scan",
        "severity": "high",
        "rule_matched": "PORT_SCAN_THRESHOLD",
        "confidence_score": 0.9
    }
"""

from collections import defaultdict
from config import Config


def detect_port_scan(recent_flows, new_flow):
    """Flags a source IP hitting many distinct destination ports quickly."""
    src_ip = new_flow["src_ip"]
    window = [f for f in recent_flows if f["src_ip"] == src_ip]
    distinct_ports = {f["dst_port"] for f in window} | {new_flow["dst_port"]}

    if len(distinct_ports) >= Config.PORT_SCAN_THRESHOLD:
        return {
            "attack_type": "Port Scan",
            "severity": "high",
            "rule_matched": "PORT_SCAN_THRESHOLD",
            "confidence_score": 0.9,
        }
    return None


def detect_syn_flood(recent_flows, new_flow):
    """Flags excessive SYN packets from one source IP in a short window."""
    if new_flow.get("flag") != "SYN":
        return None

    src_ip = new_flow["src_ip"]
    syn_count = sum(
        1 for f in recent_flows if f["src_ip"] == src_ip and f.get("flag") == "SYN"
    ) + 1

    if syn_count >= Config.SYN_FLOOD_THRESHOLD:
        return {
            "attack_type": "SYN Flood",
            "severity": "critical",
            "rule_matched": "SYN_FLOOD_THRESHOLD",
            "confidence_score": 0.95,
        }
    return None


def detect_brute_force(recent_flows, new_flow):
    """Flags repeated connection attempts to a sensitive port (SSH/RDP/etc)."""
    dst_port = new_flow.get("dst_port")
    if dst_port not in Config.SENSITIVE_PORTS:
        return None

    src_ip = new_flow["src_ip"]
    attempts = sum(
        1 for f in recent_flows
        if f["src_ip"] == src_ip and f.get("dst_port") == dst_port
    ) + 1

    if attempts >= Config.BRUTE_FORCE_THRESHOLD:
        return {
            "attack_type": "Brute Force",
            "severity": "high",
            "rule_matched": "BRUTE_FORCE_THRESHOLD",
            "confidence_score": 0.85,
        }
    return None


def detect_dos(recent_flows, new_flow):
    """Flags an abnormally high packet rate from a single source IP."""
    src_ip = new_flow["src_ip"]
    packet_count = sum(
        1 for f in recent_flows if f["src_ip"] == src_ip
    ) + 1

    if packet_count >= Config.DOS_PACKET_RATE_THRESHOLD:
        return {
            "attack_type": "Denial of Service (DoS)",
            "severity": "critical",
            "rule_matched": "DOS_PACKET_RATE_THRESHOLD",
            "confidence_score": 0.9,
        }
    return None


# Order matters a little: more specific rules first
RULES = [
    detect_syn_flood,
    detect_port_scan,
    detect_brute_force,
    detect_dos,
]


def run_all_rules(recent_flows, new_flow):
    """Runs every rule against the new flow, returns the first (highest
    priority) match, or None if traffic looks normal."""
    for rule_fn in RULES:
        result = rule_fn(recent_flows, new_flow)
        if result:
            return result
    return None
