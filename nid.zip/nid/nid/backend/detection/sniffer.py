"""
Simulated traffic generator.

Instead of live packet sniffing (which needs root and a real interface),
this generates realistic-looking flows — mostly normal, with periodic
bursts that mimic port scans, SYN floods, and brute force attempts —
and feeds them through the analyzer. Good for demos and safe for any
machine/network.

Run standalone:
    python sniffer.py
Or import `simulate_flow()` / `run_simulation()` from app.py to drive it
from a background thread.
"""

import random
import time
from detection.analyzer import process_flow

NORMAL_IPS = [f"192.168.1.{i}" for i in range(2, 30)]
ATTACKER_IPS = ["10.0.0.66", "203.0.113.45", "198.51.100.23"]
COMMON_PORTS = [80, 443, 53, 8080, 25]
SENSITIVE_PORTS = [22, 23, 21, 3389, 3306]
PROTOCOLS = ["TCP", "UDP", "ICMP"]
FLAGS = ["SYN", "ACK", "FIN", "PSH", None]


def _random_normal_flow():
    return {
        "src_ip": random.choice(NORMAL_IPS),
        "dst_ip": "192.168.1.1",
        "src_port": random.randint(1024, 65535),
        "dst_port": random.choice(COMMON_PORTS),
        "protocol": random.choice(PROTOCOLS),
        "packet_size": random.randint(64, 1500),
        "flag": random.choice(FLAGS),
        "duration": round(random.uniform(0.01, 2.0), 3),
        "packets_count": random.randint(1, 5),
        "bytes_count": random.randint(64, 4000),
    }


def _random_attack_flow(kind):
    attacker = random.choice(ATTACKER_IPS)
    if kind == "port_scan":
        return {
            "src_ip": attacker,
            "dst_ip": "192.168.1.1",
            "src_port": random.randint(1024, 65535),
            "dst_port": random.randint(1, 1024),  # sweeps low ports
            "protocol": "TCP",
            "packet_size": random.randint(40, 60),
            "flag": "SYN",
            "duration": 0.01,
            "packets_count": 1,
            "bytes_count": 60,
        }
    if kind == "syn_flood":
        return {
            "src_ip": attacker,
            "dst_ip": "192.168.1.1",
            "src_port": random.randint(1024, 65535),
            "dst_port": 80,
            "protocol": "TCP",
            "packet_size": 60,
            "flag": "SYN",
            "duration": 0.001,
            "packets_count": 1,
            "bytes_count": 60,
        }
    if kind == "brute_force":
        return {
            "src_ip": attacker,
            "dst_ip": "192.168.1.1",
            "src_port": random.randint(1024, 65535),
            "dst_port": random.choice(SENSITIVE_PORTS),
            "protocol": "TCP",
            "packet_size": 80,
            "flag": "PSH",
            "duration": 0.05,
            "packets_count": 1,
            "bytes_count": 80,
        }
    return _random_normal_flow()


def simulate_flow():
    """Returns a single flow dict — mostly normal, occasionally an attack."""
    roll = random.random()
    if roll < 0.85:
        return _random_normal_flow()
    elif roll < 0.92:
        return _random_attack_flow("port_scan")
    elif roll < 0.97:
        return _random_attack_flow("syn_flood")
    else:
        return _random_attack_flow("brute_force")


def run_simulation(interval=0.3, iterations=None):
    """Continuously (or for N iterations) generate flows and process them."""
    count = 0
    while iterations is None or count < iterations:
        flow = simulate_flow()
        result = process_flow(flow)
        if result["verdict"]:
            print(f"[ALERT] {result['verdict']['attack_type']} "
                  f"from {flow['src_ip']} (severity={result['verdict']['severity']})")
        count += 1
        time.sleep(interval)


if __name__ == "__main__":
    run_simulation()
