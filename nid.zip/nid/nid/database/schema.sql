-- =====================================================
-- Network Intrusion Detection System (NIDS) - Schema
-- =====================================================

CREATE DATABASE IF NOT EXISTS nids_db;
USE nids_db;

-- ---------------------------------------------------
-- 1. Admin / Login
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
    admin_id      INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email         VARCHAR(100),
    role          ENUM('admin', 'analyst') DEFAULT 'admin',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login    TIMESTAMP NULL
);

-- ---------------------------------------------------
-- 2. Network Traffic (raw/aggregated captured or simulated traffic)
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS network_traffic (
    traffic_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    src_ip          VARCHAR(45) NOT NULL,
    dst_ip          VARCHAR(45) NOT NULL,
    src_port        INT,
    dst_port        INT,
    protocol        VARCHAR(10),       -- TCP / UDP / ICMP
    packet_size     INT,
    flag            VARCHAR(20),       -- SYN, ACK, FIN, RST, etc.
    duration        FLOAT,             -- flow duration in seconds
    packets_count   INT DEFAULT 1,
    bytes_count     BIGINT DEFAULT 0,
    status          ENUM('normal', 'suspicious') DEFAULT 'normal',
    captured_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_src_ip (src_ip),
    INDEX idx_captured_at (captured_at),
    INDEX idx_status (status)
);

-- ---------------------------------------------------
-- 3. Intrusion Detection results (per-flow verdicts)
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS detections (
    detection_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    traffic_id       BIGINT NOT NULL,
    detection_method ENUM('rule', 'ml', 'hybrid') DEFAULT 'rule',
    attack_type      VARCHAR(100),     -- e.g. Port Scan, SYN Flood, Brute Force, DoS
    confidence_score FLOAT DEFAULT 0,  -- 0.0 - 1.0 (used mainly by ML layer)
    severity         ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    rule_matched     VARCHAR(150),     -- which rule fired, if any
    detected_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (traffic_id) REFERENCES network_traffic(traffic_id) ON DELETE CASCADE,
    INDEX idx_detected_at (detected_at),
    INDEX idx_attack_type (attack_type)
);

-- ---------------------------------------------------
-- 4. Alerts (generated when detections cross a threshold)
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS alerts (
    alert_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    detection_id  BIGINT NOT NULL,
    title         VARCHAR(150) NOT NULL,
    description   TEXT,
    severity      ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    status        ENUM('new', 'acknowledged', 'resolved', 'ignored') DEFAULT 'new',
    acknowledged_by INT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at   TIMESTAMP NULL,
    FOREIGN KEY (detection_id) REFERENCES detections(detection_id) ON DELETE CASCADE,
    FOREIGN KEY (acknowledged_by) REFERENCES admins(admin_id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_severity (severity)
);

-- ---------------------------------------------------
-- 5. Detection History (audit-friendly rollup, also queryable
--    directly from detections+traffic via JOIN, but kept for
--    fast historical reporting without heavy joins)
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS detection_history (
    history_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    detection_id   BIGINT NOT NULL,
    src_ip         VARCHAR(45),
    dst_ip         VARCHAR(45),
    attack_type    VARCHAR(100),
    severity       ENUM('low', 'medium', 'high', 'critical'),
    action_taken   VARCHAR(150),   -- e.g. "Blocked", "Alerted", "Logged only"
    archived_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (detection_id) REFERENCES detections(detection_id) ON DELETE CASCADE
);

-- ---------------------------------------------------
-- 6. IP Reputation / Details (for the IP/Traffic Details module)
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS ip_details (
    ip_id           INT AUTO_INCREMENT PRIMARY KEY,
    ip_address      VARCHAR(45) UNIQUE NOT NULL,
    country         VARCHAR(100),
    total_requests  INT DEFAULT 0,
    suspicious_count INT DEFAULT 0,
    is_blacklisted  BOOLEAN DEFAULT FALSE,
    first_seen      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_seen       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ---------------------------------------------------
-- 7. Reports (generated summary snapshots, e.g. PDF/CSV export log)
-- ---------------------------------------------------
CREATE TABLE IF NOT EXISTS reports (
    report_id     INT AUTO_INCREMENT PRIMARY KEY,
    admin_id      INT,
    report_type   ENUM('daily', 'weekly', 'monthly', 'custom') DEFAULT 'custom',
    date_from     DATE,
    date_to       DATE,
    total_traffic INT DEFAULT 0,
    total_alerts  INT DEFAULT 0,
    file_path     VARCHAR(255),   -- where the exported PDF/CSV is stored
    generated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(admin_id) ON DELETE SET NULL
);

-- ---------------------------------------------------
-- Seed data: default admin (password: admin123 -> hash with werkzeug in app)
-- ---------------------------------------------------
-- INSERT INTO admins (username, password_hash, email) VALUES
-- ('admin', '<generate_with_werkzeug_generate_password_hash>', 'admin@example.com');
