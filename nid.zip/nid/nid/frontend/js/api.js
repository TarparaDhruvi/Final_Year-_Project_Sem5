// Use the same origin the page was loaded from (works whether you open
// it via http://127.0.0.1:5000 or http://localhost:5000). Using a fixed,
// different host here would make the login cookie a cross-site cookie,
// which browsers block (SameSite=Lax) — breaking login/session checks.
const API_BASE = window.location.origin;

async function apiRequest(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (res.status === 401 && !path.includes("/api/session")) {
    window.location.href = "index.html";
    return null;
  }

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }

  return res.json();
}

async function requireAuth() {
  try {
    const data = await apiRequest("/api/session");
    if (!data || !data.authenticated) {
      window.location.href = "index.html";
      return null;
    }
    return data;
  } catch {
    window.location.href = "index.html";
    return null;
  }
}

function severityBadge(sev) {
  return `<span class="badge badge-${(sev || "low").toLowerCase()}">${sev || "n/a"}</span>`;
}

function statusBadge(status) {
  return `<span class="badge badge-${(status || "").toLowerCase()}">${status || ""}</span>`;
}

function fmtTime(ts) {
  if (!ts) return "—";
  const d = new Date(ts);
  return d.toLocaleString();
}

async function logout() {
  await apiRequest("/api/logout", { method: "POST" });
  window.location.href = "index.html";
}
