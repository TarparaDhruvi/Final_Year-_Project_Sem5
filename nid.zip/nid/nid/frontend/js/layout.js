const NAV_ITEMS = [
  { href: "dashboard.html", label: "Dashboard", key: "dashboard" },
  { href: "monitoring.html", label: "Traffic Monitoring", key: "monitoring" },
  { href: "alerts.html", label: "Alert Management", key: "alerts" },
  { href: "history.html", label: "Detection History", key: "history" },
  { href: "ip-details.html", label: "IP / Traffic Details", key: "ip" },
  { href: "reports.html", label: "Reports", key: "reports" },
];

function renderLayout({ active, title, subtitle }) {
  const navHtml = NAV_ITEMS.map(
    (item) => `<a class="nav-link ${item.key === active ? "active" : ""}" href="${item.href}">${item.label}</a>`
  ).join("");

  document.body.insertAdjacentHTML("afterbegin", `
    <div class="app-shell">
      <div class="sidebar">
        <div class="brand">
          <div class="brand-mark"></div>
          <div class="brand-text">NIDS CONSOLE<small>intrusion detection</small></div>
        </div>
        <nav>${navHtml}</nav>
      </div>
      <div class="main">
        <div class="topbar">
          <div>
            <h1 class="page-title">${title}</h1>
            <div class="page-sub">${subtitle || ""}</div>
          </div>
          <div class="user-chip">
            <span id="whoami">—</span>
            <button class="logout-btn" onclick="logout()">Sign out</button>
          </div>
        </div>
        <div id="page-content"></div>
      </div>
    </div>
  `);
}

async function initPage(config) {
  renderLayout(config);
  const session = await requireAuth();
  if (session) {
    document.getElementById("whoami").textContent = `${session.username} (${session.role})`;
    startAlertWatcher();
  }
  return session;
}

/* =====================================================
   Live alert popup watcher — runs on every page once
   logged in. Polls for brand-new alerts and pops a toast
   in the corner so you notice them without being on the
   Alerts page.
   ===================================================== */

const ALERT_WATCHER_POLL_MS = 4000;
const LAST_SEEN_KEY = "nids_last_alert_id";
let alertWatcherStarted = false;

function ensureToastStack() {
  let stack = document.getElementById("toast-stack");
  if (!stack) {
    stack = document.createElement("div");
    stack.id = "toast-stack";
    stack.className = "toast-stack";
    document.body.appendChild(stack);
  }
  return stack;
}

function showAlertToast(alert) {
  const stack = ensureToastStack();
  const sev = (alert.severity || "medium").toLowerCase();
  const toast = document.createElement("div");
  toast.className = `toast toast-${sev}`;
  toast.innerHTML = `
    <div class="toast-icon">!</div>
    <div class="toast-body">
      <div class="toast-top">
        <span class="toast-new-tag">NEW ALERT</span>
        ${severityBadge(alert.severity)}
      </div>
      <div class="toast-title">${alert.title || alert.attack_type || "Suspicious activity detected"}</div>
      <div class="toast-sub">${fmtTime(alert.created_at)}</div>
    </div>
    <button class="toast-close" aria-label="Dismiss">&times;</button>
    <div class="toast-timer"></div>
  `;
  toast.querySelector(".toast-close").onclick = () => dismissToast(toast);
  toast.onclick = (e) => {
    if (e.target.closest(".toast-close")) return;
    window.location.href = "alerts.html";
  };
  stack.appendChild(toast);

  // auto-dismiss
  const AUTO_DISMISS_MS = 8000;
  const timer = setTimeout(() => dismissToast(toast), AUTO_DISMISS_MS);
  toast._dismissTimer = timer;
}

function dismissToast(toast) {
  if (!toast || toast._dismissing) return;
  toast._dismissing = true;
  clearTimeout(toast._dismissTimer);
  toast.classList.add("toast-leaving");
  setTimeout(() => toast.remove(), 250);
}

async function checkForNewAlerts(isFirstRun) {
  try {
    const rows = await apiRequest("/api/alerts?status=new");
    if (!rows || !rows.length) return;

    const lastSeen = parseInt(localStorage.getItem(LAST_SEEN_KEY) || "0", 10);
    const maxId = Math.max(...rows.map((a) => a.alert_id));

    if (isFirstRun) {
      // Don't dump a wall of toasts for pre-existing alerts on first load —
      // just remember where we are and start watching from here.
      localStorage.setItem(LAST_SEEN_KEY, String(maxId));
      return;
    }

    const fresh = rows
      .filter((a) => a.alert_id > lastSeen)
      .sort((a, b) => a.alert_id - b.alert_id);

    if (fresh.length) {
      // Cap how many popups fire at once so a burst of attacks
      // doesn't flood the screen.
      fresh.slice(-4).forEach(showAlertToast);
      localStorage.setItem(LAST_SEEN_KEY, String(maxId));
    }
  } catch (e) {
    // Session may have expired mid-poll; apiRequest already redirects.
  }
}

function startAlertWatcher() {
  if (alertWatcherStarted) return;
  alertWatcherStarted = true;
  checkForNewAlerts(true);
  setInterval(() => checkForNewAlerts(false), ALERT_WATCHER_POLL_MS);
}
