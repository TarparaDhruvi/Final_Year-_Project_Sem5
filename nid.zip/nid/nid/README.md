# NIDS Project - Python Backend Without Flask

Architecture:
- Frontend: HTML, CSS, JavaScript
- Backend: Python (standard library HTTP server)
- Detection: Python
- Database: MySQL

## Run
1. Import `database/schema.sql` into MySQL.
2. Open a terminal in `backend`.
3. Install dependencies: `pip install -r requirements.txt`
4. Edit `backend/config.py` if your MySQL username/password is different.
5. Create the admin account once: `python seed_admin.py`
6. Start: `python app.py`
7. Open: `http://127.0.0.1:5000`

Default login: `admin` / `admin123`

No Flask is used. The Python backend uses the built-in `http.server` module.
