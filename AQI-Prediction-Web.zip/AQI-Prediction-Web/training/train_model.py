"""
training/train_model.py

Converts the exploratory notebook's ML workflow into a standalone,
repeatable training script.

Pipeline
--------
1. Load the raw AQI dataset (dataset/dataset.csv).
2. Clean and preprocess it the same way the notebook does:
     - drop columns that carry no predictive signal (identifiers, raw
       station/agency metadata, free-text dates),
     - impute missing pollutant readings with column medians (robust to
       the heavy right-skew typical of pollution data),
     - engineer a numeric "AQI" target from the pollutant sub-indices,
       since the raw dataset does not ship a ready-made AQI column.
3. Select the final input features actually used by the model:
       SO2, NO2, RSPM, SPM, PM2.5
4. Split into train/test sets.
5. Train a RandomForestRegressor (handles the non-linear, skewed
   relationship between pollutant concentration and AQI well, and needs
   no feature scaling).
6. Evaluate with MAE, RMSE and R^2.
7. Persist the trained model to model/model.pkl with joblib.

Run:
    python training/train_model.py
"""

import os

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

# ---------------------------------------------------------------------------
# Paths (relative, so the script works regardless of the machine it runs on)
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASET_PATH = os.path.join(BASE_DIR, "dataset", "dataset.csv")
MODEL_DIR = os.path.join(BASE_DIR, "model")
MODEL_PATH = os.path.join(MODEL_DIR, "model.pkl")

# Final feature order — the backend MUST build its input array in this
# exact order when calling model.predict().
FEATURE_COLUMNS = ["so2", "no2", "rspm", "spm", "pm2_5"]
TARGET_COLUMN = "AQI"


# ---------------------------------------------------------------------------
# Sub-index helpers
# ---------------------------------------------------------------------------
# The raw dataset (like the source CPCB-style dataset) does not include a
# ready-made AQI column, only pollutant concentrations. The notebook derives
# an AQI value from individual pollutant sub-indices, which is standard
# practice for this dataset family. These breakpoints follow the general
# shape of the Indian CPCB sub-index tables for SO2, NO2, RSPM/PM10 and
# PM2.5, simplified into linear segments so the target is well defined and
# reproducible from the raw pollutant columns alone.
def _sub_index(value, breakpoints):
    """Piecewise-linear sub-index calculation for a single pollutant."""
    if pd.isna(value):
        return np.nan
    for (c_lo, c_hi, i_lo, i_hi) in breakpoints:
        if c_lo <= value <= c_hi:
            return ((i_hi - i_lo) / (c_hi - c_lo)) * (value - c_lo) + i_lo
    # above the top breakpoint: extend the last band linearly
    c_lo, c_hi, i_lo, i_hi = breakpoints[-1]
    return ((i_hi - i_lo) / (c_hi - c_lo)) * (value - c_lo) + i_lo


SO2_BP = [(0, 40, 0, 50), (40, 80, 50, 100), (80, 380, 100, 200),
          (380, 800, 200, 300), (800, 1600, 300, 400), (1600, 2000, 400, 500)]
NO2_BP = [(0, 40, 0, 50), (40, 80, 50, 100), (80, 180, 100, 200),
          (180, 280, 200, 300), (280, 400, 300, 400), (400, 500, 400, 500)]
PM10_BP = [(0, 50, 0, 50), (50, 100, 50, 100), (100, 250, 100, 200),
           (250, 350, 200, 300), (350, 430, 300, 400), (430, 550, 400, 500)]
PM25_BP = [(0, 30, 0, 50), (30, 60, 50, 100), (60, 90, 100, 200),
           (90, 120, 200, 300), (120, 250, 300, 400), (250, 350, 400, 500)]


def compute_aqi(row):
    """AQI = max of the individual pollutant sub-indices (standard CPCB rule)."""
    sub_indices = [
        _sub_index(row["so2"], SO2_BP),
        _sub_index(row["no2"], NO2_BP),
        _sub_index(row["rspm"], PM10_BP),
        _sub_index(row["spm"], PM10_BP),
        _sub_index(row["pm2_5"], PM25_BP),
    ]
    sub_indices = [v for v in sub_indices if not pd.isna(v)]
    return max(sub_indices) if sub_indices else np.nan


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------
def load_data(path=DATASET_PATH):
    df = pd.read_csv(path)
    return df


def preprocess(df):
    df = df.copy()

    # Drop identifier / metadata columns that are not predictive and not
    # exposed to the end user (matches the "only expose real model
    # features" requirement).
    drop_cols = [
        "stn_code", "sampling_date", "state", "location", "agency",
        "type", "location_monitoring_station", "date",
    ]
    df = df.drop(columns=[c for c in drop_cols if c in df.columns])

    # Coerce pollutant columns to numeric (guards against stray strings).
    for col in FEATURE_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Impute missing pollutant values with the column median — the
    # notebook's approach for handling the heavy missingness in pm2_5,
    # spm, etc. Median is preferred over mean because pollutant readings
    # are right-skewed with outliers.
    for col in FEATURE_COLUMNS:
        median_val = df[col].median()
        df[col] = df[col].fillna(median_val)

    # Engineer the AQI target from the cleaned pollutant readings.
    df[TARGET_COLUMN] = df.apply(compute_aqi, axis=1)

    # Drop any row where the target still could not be computed.
    df = df.dropna(subset=[TARGET_COLUMN])

    return df


def train():
    print("Loading dataset...")
    df = load_data()
    print(f"Raw shape: {df.shape}")

    print("Preprocessing...")
    df = preprocess(df)
    print(f"Clean shape: {df.shape}")

    X = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMN]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    print("Training RandomForestRegressor...")
    model = RandomForestRegressor(
        n_estimators=200,
        max_depth=12,
        min_samples_leaf=3,
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)

    # Evaluation
    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)

    print("\nModel evaluation:")
    print(f"  MAE  : {mae:.3f}")
    print(f"  RMSE : {rmse:.3f}")
    print(f"  R^2  : {r2:.4f}")

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    print(f"\nSaved trained model to: {MODEL_PATH}")

    # Persist feature order + median fallback values alongside the model so
    # the backend can validate/impute consistently at inference time.
    meta = {
        "feature_order": FEATURE_COLUMNS,
        "medians": {col: float(df[col].median()) for col in FEATURE_COLUMNS},
    }
    meta_path = os.path.join(MODEL_DIR, "meta.pkl")
    joblib.dump(meta, meta_path)
    print(f"Saved feature metadata to: {meta_path}")


if __name__ == "__main__":
    train()
