/* =========================================================================
   ISOBAR — Air Quality Prediction
   Form validation, submission, and analog dial animation
   ========================================================================= */

(() => {
  "use strict";

  const FIELDS = ["so2", "no2", "rspm", "spm", "pm2_5"];
  const FIELD_LABELS = {
    so2: "SO₂", no2: "NO₂", rspm: "RSPM", spm: "SPM", pm2_5: "PM2.5",
  };

  const form = document.getElementById("aqi-form");
  const formMsg = document.getElementById("form-msg");
  const predictBtn = document.getElementById("predict-btn");

  const resultEmpty = document.getElementById("result-empty");
  const resultFilled = document.getElementById("result-filled");
  const aqiNumberEl = document.getElementById("aqi-number");
  const dialProgress = document.getElementById("dial-progress");
  const dialNeedle = document.getElementById("dial-needle");
  const categoryBadge = document.getElementById("category-badge");
  const adviceText = document.getElementById("advice-text");
  const inputRecap = document.getElementById("input-recap");

  const CATEGORY_COLORS = {
    "Good": "#2f7d5c",
    "Moderate": "#8a9a3c",
    "Poor": "#c68a2e",
    "Very Poor": "#c1652f",
    "Severe": "#a8433f",
    "Hazardous": "#7c2d43",
  };

  // ---------------------------------------------------------------------
  // Client-side validation (mirrors backend rules for instant feedback;
  // the backend re-validates everything independently).
  // ---------------------------------------------------------------------
  function validateForm() {
    let firstError = null;
    const values = {};

    FIELDS.forEach((key) => {
      const input = document.getElementById(key);
      const errorEl = document.getElementById(`err-${key}`);
      const wrapper = input.closest(".field");
      const raw = input.value.trim();

      wrapper.classList.remove("invalid");
      errorEl.textContent = "";

      if (raw === "") {
        wrapper.classList.add("invalid");
        errorEl.textContent = "Required.";
        firstError = firstError || "Please enter all required pollution parameters.";
        return;
      }

      const num = Number(raw);

      if (Number.isNaN(num)) {
        wrapper.classList.add("invalid");
        errorEl.textContent = "Enter a valid number.";
        firstError = firstError || "Please enter valid numeric values.";
        return;
      }

      if (num < 0) {
        wrapper.classList.add("invalid");
        errorEl.textContent = "Cannot be negative.";
        firstError = firstError || "Values cannot be negative.";
        return;
      }

      values[key] = num;
    });

    return { values, error: firstError };
  }

  // ---------------------------------------------------------------------
  // Animate the AQI number counting up from 0 to target
  // ---------------------------------------------------------------------
  function animateNumber(target, durationMs = 1000) {
    const start = performance.now();

    function tick(now) {
      const t = Math.min(1, (now - start) / durationMs);
      const eased = 1 - Math.pow(1 - t, 3);
      const value = target * eased;
      aqiNumberEl.textContent = value.toFixed(t >= 1 ? 2 : 1);
      if (t < 1) requestAnimationFrame(tick);
      else aqiNumberEl.textContent = target.toFixed(2);
    }
    requestAnimationFrame(tick);
  }

  // ---------------------------------------------------------------------
  // Move the analog dial: progress arc + needle rotation
  // ---------------------------------------------------------------------
  function animateDial(target, color) {
    const ARC_LENGTH = 377; // matches the semicircle path length in the SVG
    const SCALE_MAX = 500; // top of the AQI scale shown on the dial
    const pct = Math.min(1, target / SCALE_MAX);

    dialProgress.style.stroke = color;
    dialProgress.getBoundingClientRect(); // force reflow before transition
    requestAnimationFrame(() => {
      dialProgress.style.strokeDashoffset = ARC_LENGTH * (1 - pct);
    });

    const angle = -90 + pct * 180; // -90 = left (0), +90 = right (500)
    dialNeedle.style.stroke = color;
    requestAnimationFrame(() => {
      dialNeedle.style.transform = `rotate(${angle}deg)`;
    });
  }

  // ---------------------------------------------------------------------
  // Render a successful prediction result
  // ---------------------------------------------------------------------
  function renderResult(data) {
    resultEmpty.hidden = true;
    resultFilled.hidden = false;

    const color = CATEGORY_COLORS[data.category] || "#1f6f5c";

    animateNumber(data.aqi);
    animateDial(data.aqi, color);

    categoryBadge.textContent = data.category;
    categoryBadge.style.background = color;

    adviceText.textContent = data.health_advice;

    inputRecap.innerHTML = "";
    FIELDS.forEach((key) => {
      const chip = document.createElement("span");
      chip.className = "recap-chip";
      chip.innerHTML = `${FIELD_LABELS[key]}: <b>${data.inputs[key]}</b>`;
      inputRecap.appendChild(chip);
    });

    resultFilled.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  // ---------------------------------------------------------------------
  // Form submit handler
  // ---------------------------------------------------------------------
  let isSubmitting = false;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (isSubmitting) return;

    formMsg.textContent = "";

    const { values, error } = validateForm();
    if (error) {
      formMsg.textContent = error;
      return;
    }

    isSubmitting = true;
    predictBtn.disabled = true;
    predictBtn.classList.add("loading");

    try {
      const response = await fetch("/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });

      let data;
      try {
        data = await response.json();
      } catch {
        throw new Error("Unable to generate prediction. Please try again.");
      }

      if (!response.ok || !data.success) {
        throw new Error(data && data.error ? data.error : "Unable to generate prediction. Please try again.");
      }

      renderResult(data);
    } catch (err) {
      formMsg.textContent = err.message || "Unable to generate prediction. Please try again.";
    } finally {
      isSubmitting = false;
      predictBtn.disabled = false;
      predictBtn.classList.remove("loading");
    }
  });

  // Clear individual field errors as the user types
  FIELDS.forEach((key) => {
    const input = document.getElementById(key);
    input.addEventListener("input", () => {
      input.closest(".field").classList.remove("invalid");
      document.getElementById(`err-${key}`).textContent = "";
    });
  });

  // ---------------------------------------------------------------------
  // Hero demo dial — draw evenly spaced tick marks around the rim
  // ---------------------------------------------------------------------
  (function drawDemoTicks() {
    const group = document.querySelector(".dial-ticks");
    if (!group) return;
    const cx = 160, cy = 160, rOuter = 132, rInner = 120;
    const svgNS = "http://www.w3.org/2000/svg";

    for (let i = 0; i < 24; i++) {
      const angle = (i / 24) * Math.PI * 2 - Math.PI / 2;
      const x1 = cx + rInner * Math.cos(angle);
      const y1 = cy + rInner * Math.sin(angle);
      const x2 = cx + rOuter * Math.cos(angle);
      const y2 = cy + rOuter * Math.sin(angle);
      const tick = document.createElementNS(svgNS, "line");
      tick.setAttribute("x1", x1.toFixed(1));
      tick.setAttribute("y1", y1.toFixed(1));
      tick.setAttribute("x2", x2.toFixed(1));
      tick.setAttribute("y2", y2.toFixed(1));
      tick.setAttribute("stroke", "rgba(28,42,38,0.18)");
      tick.setAttribute("stroke-width", i % 6 === 0 ? "2" : "1");
      group.appendChild(tick);
    }
  })();
})();
