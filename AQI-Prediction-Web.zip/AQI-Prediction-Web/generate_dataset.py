"""
Generates a realistic synthetic AQI dataset matching the schema described
in the project brief (mirroring the well-known India CPCB AQI dataset
structure: stn_code, sampling_date, state, location, agency, type, so2,
no2, rspm, spm, location_monitoring_station, pm2_5, date).

NOTE: No original notebook/dataset file was provided alongside the prompt,
so this script builds a schema-faithful synthetic dataset (with realistic
missingness patterns in pm2_5, spm, agency, and stn_code, matching what the
brief describes) so the training pipeline in training/train_model.py has
real data to run against end-to-end.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 6000

states = ["Delhi", "Maharashtra", "West Bengal", "Tamil Nadu", "Karnataka",
          "Gujarat", "Uttar Pradesh", "Rajasthan", "Punjab", "Kerala"]
state_location_map = {
    "Delhi": ["ITO", "Anand Vihar", "R K Puram", "Punjabi Bagh"],
    "Maharashtra": ["Mumbai", "Pune", "Nagpur", "Nashik"],
    "West Bengal": ["Kolkata", "Howrah", "Siliguri"],
    "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai"],
    "Karnataka": ["Bengaluru", "Mysuru", "Hubli"],
    "Gujarat": ["Ahmedabad", "Surat", "Vadodara"],
    "Uttar Pradesh": ["Lucknow", "Kanpur", "Agra"],
    "Rajasthan": ["Jaipur", "Jodhpur", "Udaipur"],
    "Punjab": ["Ludhiana", "Amritsar", "Patiala"],
    "Kerala": ["Kochi", "Thiruvananthapuram", "Kozhikode"],
}
agencies = ["CPCB", "SPCB", "Board", None, None]  # some missing
types_ = ["Residential", "Industrial", "Sensitive", "Residential and others"]
stn_codes = [f"STN{100+i}" for i in range(40)]

rows = []
dates = pd.date_range("2010-01-01", "2015-12-31", freq="D")

for i in range(N):
    state = np.random.choice(states)
    location = np.random.choice(state_location_map[state])
    agency = np.random.choice(agencies)
    type_ = np.random.choice(types_)
    stn_code = np.random.choice(stn_codes) if np.random.rand() > 0.15 else None
    date = np.random.choice(dates)

    # Base pollutant simulation with correlated structure
    so2 = np.clip(np.random.gamma(2.0, 6.0), 0, 90)
    no2 = np.clip(np.random.gamma(2.5, 10.0), 0, 150)
    rspm = np.clip(np.random.gamma(3.0, 40.0) + 0.6 * so2, 0, 500)
    spm = np.clip(rspm * np.random.uniform(1.1, 1.8) + np.random.normal(0, 20), 0, 800)
    pm2_5 = np.clip(rspm * np.random.uniform(0.4, 0.7) + np.random.normal(0, 10), 0, 400)

    # Introduce realistic missingness
    if np.random.rand() < 0.35:
        pm2_5 = np.nan
    if np.random.rand() < 0.25:
        spm = np.nan
    if np.random.rand() < 0.05:
        so2 = np.nan
    if np.random.rand() < 0.05:
        no2 = np.nan
    if np.random.rand() < 0.1:
        rspm = np.nan

    rows.append({
        "stn_code": stn_code,
        "sampling_date": pd.Timestamp(date).strftime("%d-%m-%Y"),
        "state": state,
        "location": location,
        "agency": agency,
        "type": type_,
        "so2": so2,
        "no2": no2,
        "rspm": rspm,
        "spm": spm,
        "location_monitoring_station": f"{location} Station",
        "pm2_5": pm2_5,
        "date": pd.Timestamp(date).strftime("%Y-%m-%d"),
    })

df = pd.DataFrame(rows)
df.to_csv("dataset/dataset.csv", index=False)
print("Dataset generated:", df.shape)
print(df.isna().sum())
