"""
app.py

Flask backend for the AI-Powered AQI Prediction Web Application.

Responsibilities:
    - Load the trained model (and feature metadata) ONCE at startup.
    - Serve the frontend dashboard.
    - Expose POST /predict for inference only (no retraining at request time).
    - Validate all incoming input defensively before it ever reaches the model.
    - Never leak internal exceptions/stack traces to the client.
"""

import os

import joblib
import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "model.pkl")
META_PATH = os.path.join(BASE_DIR, "model", "meta.pkl")

# Feature order MUST match training/train_model.py exactly.
FEATURE_ORDER = ["so2", "no2", "rspm", "spm", "pm2_5"]

# Human-readable labels used only for error messages.
FEATURE_LABELS = {
    "so2": "SO2",
    "no2": "NO2",
    "rspm": "RSPM",
    "spm": "SPM",
    "pm2_5": "PM2.5",
}

# ---------------------------------------------------------------------------
# Load model once at startup (not per-request).
# ---------------------------------------------------------------------------
model = None
model_meta = None
model_load_error = None

try:
    model = joblib.load(MODEL_PATH)
    if os.path.exists(META_PATH):
        model_meta = joblib.load(META_PATH)
except Exception as exc:  # noqa: BLE001
    # Keep the app importable/runnable even if the model file is missing;
    # /predict will return a clean error instead of crashing the process.
    model_load_error = str(exc)
    print(f"[WARNING] Could not load model at startup: {exc}")


# ---------------------------------------------------------------------------
# AQI category + health advisory (UI interpretation layer, NOT produced by
# the ML model itself — the model only outputs a numeric AQI value).
# ---------------------------------------------------------------------------
def classify_aqi(aqi_value):
    """
    Category thresholds follow the standard Indian CPCB AQI bands.
    This is a separate rule-based interpretation layer applied to the
    model's numeric output; it is not learned by the model.
    """
    if aqi_value <= 50:
        return "Good", "Air quality is considered satisfactory, and air pollution poses little or no risk."
    if aqi_value <= 100:
        return "Moderate", "Air quality is acceptable for most people. Unusually sensitive individuals should consider reducing prolonged outdoor exertion."
    if aqi_value <= 200:
        return "Poor", "Sensitive groups (children, elderly, people with respiratory or heart conditions) may experience discomfort. Consider limiting prolonged outdoor activity."
    if aqi_value <= 300:
        return "Very Poor", "Health effects may be experienced by the general population. Reduce outdoor exertion and keep windows closed where possible."
    if aqi_value <= 400:
        return "Severe", "Health warnings of emergency conditions. Avoid outdoor activity; use an air purifier and a well-fitted mask if you must go outside."
    return "Hazardous", "Serious risk to the entire population. Remain indoors, keep air filtration running, and follow local health authority guidance."


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def validate_and_parse(payload):
    """
    Validates the incoming JSON payload.
    Returns (values_dict, error_message). Exactly one of the two is None.
    """
    if payload is None:
        return None, "Please enter all required pollution parameters."

    values = {}
    for key in FEATURE_ORDER:
        label = FEATURE_LABELS[key]

        if key not in payload or payload[key] in (None, "", "null"):
            return None, f"{label} is required. Please enter all required pollution parameters."

        raw_value = payload[key]

        try:
            numeric_value = float(raw_value)
        except (TypeError, ValueError):
            return None, f"Please enter a valid numeric value for {label}."

        if numeric_value != numeric_value or numeric_value in (float("inf"), float("-inf")):
            return None, f"Please enter a valid numeric value for {label}."

        if numeric_value < 0:
            return None, f"{label} cannot be negative."

        # Sanity ceiling to reject obviously bogus / mistyped input while
        # still allowing genuinely extreme pollution readings through.
        if numeric_value > 5000:
            return None, f"{label} value looks out of range. Please double-check the reading."

        values[key] = numeric_value

    return values, None


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    if model is None:
        return jsonify({
            "success": False,
            "error": "Prediction model is not available right now. Please try again later.",
        }), 503

    try:
        payload = request.get_json(silent=True)
    except Exception:  # noqa: BLE001
        payload = None

    values, error = validate_and_parse(payload)
    if error:
        return jsonify({"success": False, "error": error}), 400

    try:
        # Build the feature row in the EXACT order/column-names used during
        # training (a DataFrame keeps scikit-learn's feature-name check happy
        # and avoids ambiguity about column order).
        feature_row = pd.DataFrame([[values[col] for col in FEATURE_ORDER]], columns=FEATURE_ORDER)
        prediction = model.predict(feature_row)[0]
        aqi_value = round(float(prediction), 2)

        # Clip to a sane display floor (AQI cannot be negative).
        aqi_value = max(aqi_value, 0.0)

        category, advice = classify_aqi(aqi_value)

        return jsonify({
            "success": True,
            "aqi": aqi_value,
            "category": category,
            "health_advice": advice,
            "inputs": values,
        })

    except Exception as exc:  # noqa: BLE001
        # Never expose the raw exception/stack trace to the client.
        print(f"[ERROR] Prediction failure: {exc}")
        return jsonify({
            "success": False,
            "error": "Unable to generate prediction. Please try again.",
        }), 500


@app.errorhandler(404)
def not_found(_e):
    return jsonify({"success": False, "error": "Not found."}), 404


@app.errorhandler(500)
def server_error(_e):
    return jsonify({"success": False, "error": "Something went wrong on our end. Please try again."}), 500


if __name__ == "__main__":
    # debug=True is fine for local development only.
    app.run(debug=True, host="0.0.0.0", port=5000)
